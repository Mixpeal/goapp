<?php
/*
header("Content-type: application/json");*/
if(isset($flash_notice))
{
    echo $flash_notice;
} 
?>